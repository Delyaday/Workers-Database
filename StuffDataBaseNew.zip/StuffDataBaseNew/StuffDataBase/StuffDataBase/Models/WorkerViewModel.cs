﻿using Microsoft.AspNetCore.Http;

using System.ComponentModel.DataAnnotations;

namespace StuffDataBase.Models
{
    public class WorkerViewModel
    {
        [Required(ErrorMessage = "Пожалуйста, введите имя")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Пожалуйста, введите фамилию")]
        public string Surname { get; set; }

        [Required(ErrorMessage = "Пожалуйста, введите номер телефона")]
        public string PhoneNumber { get; set; }

        [Required(ErrorMessage = "Пожалуйста, выберите должность")]
        public string Position { get; set; }

        [Required(ErrorMessage = "Пожалуйста, ухажите размер заработной платы")]
        public string Salary { get; set; }
        public IFormFile ProfileImage { get; set; }
    }
}
