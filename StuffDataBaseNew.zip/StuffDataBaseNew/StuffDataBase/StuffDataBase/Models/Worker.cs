﻿namespace StuffDataBase.Models
{
    public class Worker
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Surname { get; set; }

        public string FullName => Name + " " + Surname;

        public string PhoneNumber { get; set; }

        public string Position { get; set; }

        public string Salary { get; set; }

        public string ProfilePicture { get; set; }
    }
}
