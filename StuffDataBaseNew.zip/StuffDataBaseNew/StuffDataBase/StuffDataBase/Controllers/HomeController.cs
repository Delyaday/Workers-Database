﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using StuffDataBase.Models;

using System;
using System.IO;
using System.Threading.Tasks;

namespace StuffDataBase.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationContext db;
        private readonly IWebHostEnvironment webHostEnvironment;

        public HomeController(ApplicationContext context, IWebHostEnvironment hostEnvironment)
        {
            db = context;
            webHostEnvironment = hostEnvironment;
        }

        public async Task<IActionResult> Index()
        {
            return View(await db.Workers.ToListAsync());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(WorkerViewModel model)
        {
            if (ModelState.IsValid)
            {
                string uniqueFileName = UploadedFile(model);

                Worker worker = new Worker
                {
                    Name = model.Name,
                    Surname = model.Surname,
                    PhoneNumber = model.PhoneNumber,
                    Position = model.Position,
                    Salary = model.Salary,
                    ProfilePicture = uniqueFileName,
                };
                db.Add(worker);
                await db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                Worker worker = await db.Workers.FirstOrDefaultAsync(p => p.Id == id);
                if (worker != null)
                    return View(worker);
            }
            return NotFound();
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                Worker worker = await db.Workers.FirstOrDefaultAsync(p => p.Id == id);
                if (worker != null)
                {
                    ViewBag.WorkerId = worker.Id;

                    //Тут вьюмодель
                    var viewModel = new WorkerViewModel()
                    {
                        Name = worker.Name,
                        Surname = worker.Surname,
                        PhoneNumber = worker.PhoneNumber,
                        Position = worker.Position,
                        Salary = worker.Salary,
                        ProfileImage = null
                    };

                    return View(viewModel);
                }
            }
            return NotFound();
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, WorkerViewModel viewModel)
        {
            var worker = new Worker()
            {
                Id = id,
                Name = viewModel.Name,
                Surname = viewModel.Surname,
                PhoneNumber = viewModel.PhoneNumber,
                Salary = viewModel.Salary,
                Position = viewModel.Position
            };

            // Загрузка новой картинки и замена её имени в модели. 
            if (viewModel.ProfileImage != null)
            {
                string uniqueFileName = UploadedFile(viewModel);
                worker.ProfilePicture = uniqueFileName;
            }
            else
            {
                var temp = await db.Workers.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id);
                worker.ProfilePicture = temp.ProfilePicture;
            }

            db.Workers.Update(worker);
            await db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        [HttpDelete] 
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Worker user = new Worker { Id = id.Value };
                db.Entry(user).State = EntityState.Deleted;
                await db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return NotFound();
        }

        private string UploadedFile(WorkerViewModel model)
        {
            string uniqueFileName = null;

            if (model.ProfileImage != null)
            {
                string uploadsFolder = Path.Combine(webHostEnvironment.WebRootPath, "images");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + model.ProfileImage.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.ProfileImage.CopyTo(fileStream);
                }
            }
            return uniqueFileName;
        }
    }
}
